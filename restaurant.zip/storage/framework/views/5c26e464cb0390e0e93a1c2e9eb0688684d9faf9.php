<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <?php echo $__env->make('admin.admincss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-scroller">
      <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div style="position: relative; top:60px; right:-100px">
        <form action="<?php echo e(url('/uploadchef')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div>
            <label for="">Name</label>
            <input style="color: #000" type="text" name="name" required>
          </div>
          <div>
            <label for="">Speciality</label>
            <input style="color: #000"  type="text" name="speciality" required>
          </div>
          <div>
            <label for="">Image</label>
            <input type="file" name="image" id="" placeholder="Write your product image">
          </div>
          <div>
            <input style="color: #000" type="submit" value="Save">
          </div>
        </form>

        <div>
          <table class="table bg-white text-center" style="position: relative; top:60px; right: -60px">
            <tr>
              <th>Chef Name</th>
              <th>Speciality</th>
              <th>Image</th>
              <th>Action</th>
              <th>Action Two</th>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($data->name); ?></td>
                <td><?php echo e($data->speciality); ?></td>
                <td><img src="uploads/chefs/<?php echo e($data->image); ?>" alt="Chef Image"></td>
                <td><a href="<?php echo e(url('/deletechef', $data->id)); ?>">Delete</a></td>
                <td><a href="<?php echo e(url('/updatechef', $data->id)); ?>">Update</a></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
        </div>
      </div>
    </div>
      <?php echo $__env->make('admin.adminscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\resturantms\restaurant\resources\views/admin/adminchef.blade.php ENDPATH**/ ?>