<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <?php echo $__env->make('admin.admincss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-scroller">
      <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
      <div style="position: relative; top:60px; right:-100px">
        <form action="<?php echo e(url('/uploadfood')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div>
            <label for="">Title</label>
            <input style="color: #000" type="text" name="txtTitle" id="" placeholder="Write your product title">
          </div>
          <div>
            <label for="">Price</label>
            <input style="color: #000"  type="text" name="txtPrice" id="" placeholder="Write your product price">
          </div>
          <div>
            <label for="">Image</label>
            <input type="file" name="txtImage" id="" placeholder="Write your product image">
          </div>
          <div>
            <label for="">Description</label>
            <input  style="color: #000" type="text" name="txtDescription" id="" placeholder="Write your product description">
          </div>
          <div>
            <input style="color: #000" type="submit" value="Save">
          </div>
        </form>

        <div>
          <table class="table bg-white text-center" style="position: relative; top:60px; right: -60px">
            <tr>
              <th>Title</th>
              <th>Price</th>
              <th>Image</th>
              <th>Description</th>
              <th>Action</th>
              <th>Action Two</th>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($data->titls); ?></td>
                <td><?php echo e($data->price); ?></td>
                <td><img src="uploads/foods/<?php echo e($data->image); ?>" alt="Foods Image"></td>
                <td><?php echo e($data->description); ?></td>
                <td><a href="<?php echo e(url('/deletemanu', $data->id)); ?>">Delete</a></td>
                <td><a href="<?php echo e(url('/updateview', $data->id)); ?>">Update</a></td>
                
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </table>
        </div>
      </div>
    </div>
      <?php echo $__env->make('admin.adminscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\resturantms\restaurant\resources\views/admin/foodmanu.blade.php ENDPATH**/ ?>