<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <?php echo $__env->make('admin.admincss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-scroller">
      <?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div>
          <table class="table bg-white text-center" style="position: relative; top:60px; right: -60px">
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Guest</th>
              <th>Date</th>
              <th>Time</th>
              <th>Message</th>
              <th>Action</th>
            </tr>

            <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($data2->name); ?></td>
                <td><?php echo e($data2->email); ?></td>
                <td><?php echo e($data2->phone); ?></td>
                <td><?php echo e($data2->guest); ?></td>
                <td><?php echo e($data2->date); ?></td>
                <td><?php echo e($data2->time); ?></td>
                <td><?php echo e($data2->message); ?></td>
                <td><a href="<?php echo e(url('/deletereservation', $data2->id)); ?>">Delete</a></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
        </div>
      </div>
      <?php echo $__env->make('admin.adminscript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\resturantms\restaurant\resources\views/admin/adminreservation.blade.php ENDPATH**/ ?>