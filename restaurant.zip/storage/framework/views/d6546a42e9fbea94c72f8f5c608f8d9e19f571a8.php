
<?php /**PATH C:\xampp\htdocs\Laravel\resturantms\restaurant\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>